// routes/authRoutes.js
const express = require("express");
const router = express.Router();
const { register, adminLogin, getAllUsers } = require("../Controllers/authController");

// Registration route for customer and admin
router.post("/register", register);

// Admin login
router.post("/admin/login", adminLogin);
router.get("/users", getAllUsers);


module.exports = router;
