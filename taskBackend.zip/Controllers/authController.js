// controllers/authController.js
const User = require("../Models/UserSchema");
const bcrypt = require("bcrypt");
const jwt = require("jsonwebtoken");

// Register user (admin or customer)
exports.register = async (req, res) => {
  const { firstName, lastName, email, password, role } = req.body;
  try {
    const existingUser = await User.findOne({ where: { email } });
    if (existingUser)
      return res.status(400).json({ message: "Email already exists" });

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({
      firstName,
      lastName,
      email,
      password: hashedPassword,
      role,
      isVerified: true, // Set true for now (simulate verification)
    });

    res
      .status(201)
      .json({ message: `${role} registered successfully`, data: user });
  } catch (error) {
    res.status(500).json({ message: "Registration failed", error });
  }
};

// Admin login
exports.adminLogin = async (req, res) => {
  const { email, password } = req.body;
  try {
    const user = await User.findOne({ where: { email } });
    if (!user)
      return res.status(400).json({ message: "Invalid email or password" });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: "Invalid email or password" });

    if (user.role !== "admin") {
      return res
        .status(403)
        .json({ message: "You are not allowed to login from here" });
    }

    const token = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: "1d" }
    );

    res.json({ token, message: "Admin logged in successfully", data: user });
  } catch (error) {
    res.status(500).json({ message: "Login failed", error });
  }
};

exports.getAllUsers = async (req, res) => {
  try {
    const users = await User.findAll({
      attributes: { exclude: ["password"] }, // Don't show passwords
    });
    res.status(200).json({ message: "Data show successfully", data: users });
  } catch (error) {
    res.status(500).json({ message: "Failed to fetch users", error });
  }
};
